var access_token = 'pmC65uZxPGfFQtJ25gg2wvhGxFlsuBpTp6ItSU-MtMdI';
var wsURI = 'wss://api.us-south.text-to-speech.watson.cloud.ibm.com/instances/ddf8833b-6d70-4f24-8763-e7ada2d86a63/v1/recognize'
    + '?access_token=' + access_token
    + '&model=es-ES_BroadbandModel'; 4
console.log(wsURI);

module.exports = () => {
    
}