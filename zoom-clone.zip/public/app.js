const videoGrid = document.getElementById("video_grid");
const muteBtn = document.getElementById("muteBtn")
const cameraoff = document.getElementById("cameraoff")
const selectCam = document.getElementById("selectCam")
const selectMic = document.getElementById("selectMic")
const screenShare = document.getElementById("screenShare")

// socket init 
const socket = io();

let mediaStream;
let mute = false;
let camera = true;
let currentCam;
let RTC;

// sound mute handler
muteBtn.addEventListener("click", (e) => {
    if (mute) {
        mute = false;
        muteBtn.textContent = "Mute yourself";
        mediaStream.getAudioTracks()
            .forEach(track => {
                track.enabled = true;
            })
    } else {
        mute = true;
        muteBtn.textContent = "Unmute yourself";
        mediaStream.getAudioTracks()
            .forEach(track => {
                track.enabled = false;
            })
    }


})



cameraoff.addEventListener('click', () => {
    if (camera) {
        cameraoff.textContent = "Turn on camera";
        camera = false;
        mediaStream.getVideoTracks()
            .forEach(track => {
                track.enabled = false;
            })

    } else {
        cameraoff.textContent = "Turn off camera";
        camera = true;
        mediaStream.getVideoTracks()
            .forEach(track => {
                track.enabled = true;
            })
    }
})


// getting the medias
async function getMedia(cameraId, micId) {


    currentCam = cameraId === null ? currentCam : cameraId;

    const initialConstraits = {
        video: true,
        audio: true
    }

    const preferredCameraConstraints = {
        video: {
            deviceId: cameraId
        },
        audio: true,
    }

    const videoOption = currentCam ? {
        deviceId: currentCam
    } : true;

    const preferredMicConstraints = {
        video: videoOption,
        audio: {
            deviceId: micId
        },
    }

    try {


        mediaStream = await window.navigator.mediaDevices.getUserMedia(cameraId || micId ? cameraId ? preferredCameraConstraints : preferredMicConstraints : initialConstraits)
        // send joining notification

        displayMedia()
        getAllCameras()
        getAllMics()
        makeWebRTCConnection();

        // room joining event
        socket.emit('joinRoom', roomId)

    } catch (error) {
        console.log(error);
    }


}
getMedia()




async function getScreenMedia() {
    try {
        mediaStream = await navigator.mediaDevices.getDisplayMedia({
            audio: true,
            video: true,
        });
        displayMedia()
    } catch (error) {
        console.log(error);
    }
}


screenShare.addEventListener('click', getScreenMedia)


// display media
function displayMedia() {
    const video = document.createElement('video');
    video.srcObject = mediaStream; //first cam
    video.addEventListener('loadedmetadata', () => {
        video.play()
    })
    videoGrid.appendChild(video)

}

// get all cameras
async function getAllCameras() {
    const currentCamera = mediaStream.getVideoTracks()[0];
    const allDevices = await window.navigator.mediaDevices.enumerateDevices();
    selectCam.innerHTML = ''
    allDevices.forEach(device => {

        if (device.kind === "videoinput") {
            const option = document.createElement('option');
            option.value = device.deviceId;
            option.textContent = device.label;
            option.selected = device.label === currentCamera.label ? true : false;
            selectCam.appendChild(option)
        }
    })
}




// get all mics
async function getAllMics() {
    const currentMic = mediaStream.getAudioTracks()[0];
    const allDevices = await window.navigator.mediaDevices.enumerateDevices();
    selectMic.innerHTML = ''
    allDevices.forEach(device => {

        if (device.kind === "audioinput") {
            const option = document.createElement('option');
            option.value = device.deviceId;
            option.textContent = device.label;
            option.selected = device.label === currentMic.label ? true : false;
            selectMic.appendChild(option)
        }
    })
}



// select a specific camera
selectCam.addEventListener('input', (e) => {
    const cameraId = e.target.value;
    getMedia(cameraId)

})

// select a specific camera
selectMic.addEventListener('input', (e) => {
    const micId = e.target.value;
    getMedia(null, micId)
})







/// socket

socket.on("newJoining", () => {
    makeAOffer()
})


// make WebRTC connection
function makeWebRTCConnection() {
    // rtc init
    RTC = new RTCPeerConnection({
        iceServers: [
            {
                urls: 'stun:stun1.l.google.com:19302'
            },
            {
                urls: 'stun:stun3.l.google.com:19302'
            },
            {
                urls: 'stun:stun4.l.google.com:19302'
            }
        ]
    });

    // add media tracks to RTC
    mediaStream.getTracks()
        .forEach(track => {
            RTC.addTrack(track, mediaStream)
        })

    // send ICE candidate
    RTC.addEventListener('icecandidate', (data) => {
        socket.emit("sendIceCandidate", data.candidate, roomId);
    })

    // send ICE candidate
    RTC.addEventListener('addstream', (data) => {
        const videoTag = document.createElement('video');
        console.log(data.stream);
        videoTag.srcObject = data.stream; //one to fiddle with
        //-----------------

        var access_token = 'eyJraWQiOiIyMDIzMDgwOTA4MzQiLCJhbGciOiJSUzI1NiJ9.eyJpYW1faWQiOiJpYW0tU2VydmljZUlkLWY3NGFiOGJlLThiODUtNDJmOC05OGMwLThjOTI3NjE5ZWVmMyIsImlkIjoiaWFtLVNlcnZpY2VJZC1mNzRhYjhiZS04Yjg1LTQyZjgtOThjMC04YzkyNzYxOWVlZjMiLCJyZWFsbWlkIjoiaWFtIiwianRpIjoiMDZhNTBjNGItOWY5OS00NzdmLWI3OWEtYThhNDI1YTU3ZDMwIiwiaWRlbnRpZmllciI6IlNlcnZpY2VJZC1mNzRhYjhiZS04Yjg1LTQyZjgtOThjMC04YzkyNzYxOWVlZjMiLCJuYW1lIjoiMGVmNTI0MzMtY2RmNy00MDEwLTg5NWItZWZiYTRkYmY5NTBjIiwic3ViIjoiU2VydmljZUlkLWY3NGFiOGJlLThiODUtNDJmOC05OGMwLThjOTI3NjE5ZWVmMyIsInVuaXF1ZV9pbnN0YW5jZV9jcm5zIjpbImNybjp2MTpibHVlbWl4OnB1YmxpYzp0ZXh0LXRvLXNwZWVjaDp1cy1zb3V0aDphLzliNDQzNmE5MmVkMzQ5OWE4ZDlhMTJlNTUyNjQwNzk1OmRkZjg4MzNiLTZkNzAtNGYyNC04NzYzLWU3YWRhMmQ4NmE2Mzo6Il0sInN1Yl90eXBlIjoiU2VydmljZUlkIiwiYXV0aG4iOnsic3ViIjoiU2VydmljZUlkLWY3NGFiOGJlLThiODUtNDJmOC05OGMwLThjOTI3NjE5ZWVmMyIsImlhbV9pZCI6ImlhbS1TZXJ2aWNlSWQtZjc0YWI4YmUtOGI4NS00MmY4LTk4YzAtOGM5Mjc2MTllZWYzIiwic3ViX3R5cGUiOiJTZXJ2aWNlSWQiLCJuYW1lIjoiMGVmNTI0MzMtY2RmNy00MDEwLTg5NWItZWZiYTRkYmY5NTBjIn0sImFjY291bnQiOnsidmFsaWQiOnRydWUsImJzcyI6IjliNDQzNmE5MmVkMzQ5OWE4ZDlhMTJlNTUyNjQwNzk1IiwiZnJvemVuIjp0cnVlfSwiaWF0IjoxNjkxNzU2ODg1LCJleHAiOjE2OTE3NjA0ODUsImlzcyI6Imh0dHBzOi8vaWFtLmNsb3VkLmlibS5jb20vaWRlbnRpdHkiLCJncmFudF90eXBlIjoidXJuOmlibTpwYXJhbXM6b2F1dGg6Z3JhbnQtdHlwZTphcGlrZXkiLCJzY29wZSI6ImlibSBvcGVuaWQiLCJjbGllbnRfaWQiOiJkZWZhdWx0IiwiYWNyIjoxLCJhbXIiOlsicHdkIl19.LAl0Gsvbedw2_835kbEtPwCobxZzuXxAELARkavY7NVdsgpJl9ivcKrqkBAx6rL02eh1stopS0Dk4sCy3z5gyz7zyljLHYNW6EC1R-h13fTQEPXyZpb8gqDCX_7ZxXnmyPFmmFV2AZsBxN9MLBveU8zS_WPNqv4h43_VxspEBBCA6w-ZoSrYlaPzYdycsJnxIvAd4wpgxyOcA1ebl8AKaD8sKLLIeIYdznLu3RAu47TbTjbKcVhVJwBthFACP_j5WUE_8RMgwKxClbV4Bf1pQt-c26QBBv1HCxeBB7oHpbdsOyFKysQD5L0IHWsWTqPZeOVfSLkZ-1CVBxZ9H3acQA';

        var wsURI = 'wss://api.us-south.text-to-speech.watson.cloud.ibm.com/instances/ddf8833b-6d70-4f24-8763-e7ada2d86a63/v1/recognize' + '?access_token=' + access_token + '&model=es-ES_BroadbandModel';

        var websocket = new WebSocket(wsURI);
        websocket.onopen = function (evt) { onOpen(evt) };
        websocket.onmessage = function (evt) { onMessage(evt) };
        websocket.onerror = function (evt) { onError(evt) };
        websocket.onclose = function (evt) { onClose(evt) };

        this.send = function (message, callback) {
            this.waitForConnection(function () {
                websocket.send(message);
                if (typeof callback !== 'undefined') {
                    callback();
                }
            }, 1000);
        };

        this.waitForConnection = function (callback, interval) {
            if (websocket.readyState === 1) {
                callback();
            } else {
                var that = this;
                // optional: implement backoff for interval here
                setTimeout(function () {
                    that.waitForConnection(callback, interval);
                }, interval);
            }
        };

        function onOpen(evt) {
            var message = {
                'action': 'start',
                'content-type': 'video/webm;codecs=vp8,opus'
            };
            this.send(JSON.stringify(message));
            console.log('connected', evt);
        }

        const mediaRecorder = new MediaRecorder(data.stream);
        mediaRecorder.start(500);
        mediaRecorder.ondataavailable = (blobEvent => {
            async function send() {
                this.send(blobEvent.data)
                console.log(blobEvent.data);
            }
            send();
        })
        function onMessage(evt) {
            console.log(evt.data);
        }

        function onClose(evt) {
            var message = {
                'action': 'stop'
            };
            this.send(JSON.stringify(message));
        }

        function onError(evt) {
            console.log("err", evt);
        }

        //-----------------

        videoTag.addEventListener('loadedmetadata', () => {
            videoTag.play()
        })

        videoGrid.appendChild(videoTag)
    })

}



// make a offer
async function makeAOffer() {
    const offer = await RTC.createOffer();
    RTC.setLocalDescription(offer)
    // send the offer 
    socket.emit("sendTheOffer", offer, roomId)
}

// receive offer
socket.on("receiveOffer", async (offer) => {
    RTC.setRemoteDescription(offer);
    const answer = await RTC.createAnswer();
    RTC.setLocalDescription(answer);

    // send the answer
    socket.emit("sendTheAnswer", answer, roomId)
})


// receive answer
socket.on("receiveAnswer", (answer) => {
    RTC.setRemoteDescription(answer)
})


// receive answer
socket.on("receiveCandidate", (candidate) => {
    RTC.addIceCandidate(candidate)
})












/*
    1. RTC connection initialization after media stream ready!
    2. add media tracks to RTC
*/



// websocket.close();